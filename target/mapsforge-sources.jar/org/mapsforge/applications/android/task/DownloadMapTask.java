package org.mapsforge.applications.android.task;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created with IntelliJ IDEA.
 * User: stanimir
 * Date: 3/21/13
 * Time: 3:22 PM
 * developer STANIMIR MARINOV
 */
public class DownloadMapTask extends AsyncTask<Context, Integer, File> {

    private static final String TAG = "DownloadUpdateTask";
    private OnTaskCompleted listener;
    private String mapFile = "bulgaria.map";
    private Context context;

    public DownloadMapTask(String mapFile, OnTaskCompleted listener) {
        this.listener = listener;
        if (mapFile != null) this.mapFile = mapFile;
    }

    @Override
    protected void onPostExecute(File path) {
        listener.onTaskCompleted(path);
    }

    @Override
    protected File doInBackground(Context... params) {

        if (params.length == 1) context = params[0];

        try {
            URL url = new URL("http://taxi-bulgaria.com/" + mapFile);
            // URL url = new URL("http://taxi-bulgaria.com:9191/" + mapFile);
            HttpURLConnection c = (HttpURLConnection) url.openConnection();

            /*if(ISSUE_DOWNLOAD_STATUS.intValue()==ECMConstant.ECM_DOWNLOADING){   todo file resume support
                File file=new File(DESTINATION_PATH);
                if(file.exists()){
                    downloaded = (int) file.length();
                    connection.setRequestProperty("Range", "bytes="+(file.length())+"-");
                }
            }else{
                connection.setRequestProperty("Range", "bytes=" + downloaded + "-");
            }*/

            c.setRequestMethod("GET");
            c.setDoOutput(true);
            c.connect();
            // getting file length
            int lenghtOfFile = c.getContentLength();

            //String PATH = "/mnt/sdcard/Download/";
            File file = context.getFilesDir();// Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS); //new File(Environment.getExternalStorageDirectory(), "Download/");
            //file.mkdirs();
            //if (file.isDirectory()) {
            File outputFile = new File(file, mapFile);
            //File outputFile = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), mapFile);
            if (outputFile.exists()) {
                outputFile.delete();
            }
            FileOutputStream fos = new FileOutputStream(outputFile);

            InputStream is = c.getInputStream();

            byte[] buffer = new byte[1024];
            int len1 = 0;
            long total = 0;
            while ((len1 = is.read(buffer)) != -1) {
                total += len1;
                // publishing the progress....
                // After this onProgressUpdate will be called
                publishProgress((int) ((total * 100) / lenghtOfFile));

                fos.write(buffer, 0, len1);
            }
            fos.close();
            is.close();

        } catch (Exception e) {
            if (e.getMessage() != null) Log.e(TAG, "error! " + e.getMessage());
        }

        //return new File(Environment.getExternalStorageDirectory(), "Download/" + mapFile);
        return new File(context.getFilesDir(), mapFile);
    }

    /**
     * Updating progress bar
     */
    protected void onProgressUpdate(Integer... progress) {
        // setting progress percentage
        listener.progressUpdated(progress[0]);
    }

    public interface OnTaskCompleted {
        void onTaskCompleted(File path);

        void progressUpdated(int progress);
    }
}