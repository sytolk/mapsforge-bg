package org.mapsforge.applications.android;

public final class BuildConfig {
  public static final boolean DEBUG = true;
}
